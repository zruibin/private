#! /usr/bin/env python3
# -*- coding: utf-8 -*- 
#
# GeneratorEPUB.py
#
# Created by Ruibin.Chow on 2022/06/27.
# Copyright (c) 2022年 Ruibin.Chow All rights reserved.
# 

"""

"""
import os, zipfile, shutil, sys, stat, datetime
import Global, Macros, Util
from RBLog import *
from string import Template as TPL

EPUB_FINAL_NAME = "../private.epub"

EPUB_OUTPUT_DIR = "../epub/"
EPUB_META_DIR = "META-INF"
EPUB_CONTENT_DIR = "OEBPS/"

EPUB_IMAGE_DIR = "image"
EPUB_ARTICLE_DIR = "article"
EPUB_VENDER_DIR = "vender"

EPUB_MINETYPE_NAME = "mimetype"
EPUB_META_CONTAINER_NAME = "container.xml"
EPUB_CONTENT_NAME = "content.opf"
EPUB_TOC_NCX_NAME = "toc.ncx"


EPUB_MINETYPE_FILE = os.path.join(EPUB_OUTPUT_DIR, EPUB_MINETYPE_NAME)
EPUB_META_PATH = os.path.join(EPUB_OUTPUT_DIR, EPUB_META_DIR)
EPUB_META_CONTAINER_FILE = os.path.join(EPUB_META_PATH, EPUB_META_CONTAINER_NAME)
EPUB_CONTENT_PATH = os.path.join(EPUB_OUTPUT_DIR, EPUB_CONTENT_DIR)
EPUB_CONTENT_FILE = os.path.join(EPUB_CONTENT_PATH, EPUB_CONTENT_NAME)
EPUB_TOC_NCX_FILE = os.path.join(EPUB_CONTENT_PATH, EPUB_TOC_NCX_NAME)

EPUB_IMAGE_PATH = os.path.join(EPUB_CONTENT_PATH, EPUB_IMAGE_DIR)
EPUB_VENDER_PATH = os.path.join(EPUB_CONTENT_PATH, EPUB_VENDER_DIR)
EPUB_ARTICLE_PATH = os.path.join(EPUB_CONTENT_PATH, EPUB_ARTICLE_DIR)


EPUB_META_CONTAINER_DATA = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
    <rootfiles>
        <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml" />
   </rootfiles>
</container>
"""

EPUB_CONTENT_ITEM_DATA = """
        <item href="${href}" id="${id}" media-type="${mediaType}" />"""

EPUB_CONTENT_ITEM_REF_DATA = """
        <itemref idref="%s" />"""


EPUB_CONTENT_DATA = """<?xml version="1.0" encoding="utf-8" ?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="book-id" version="2.0">
    <metadata xmlns="http://www.idpf.org/2007/opf" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">
        <dc:identifier id="book-id" opf:scheme="UUID">urn:uuid:d981dee5-6fed-4c0a-8e36-1wsq112sswwe</dc:identifier>
        <dc:title>个人收藏</dc:title>
        <dc:publisher>Ruibin.Chow</dc:publisher>
        <dc:publisher>Ruibin.Chow</dc:publisher>
        <dc:creator opf:role="aut">Ruibin.Chow</dc:creator>
        <dc:language>zh</dc:language>
        <meta name="cover" content="cover.jpg" />
        <meta content="2.1.0.55" name="Epuber version" />
        <dc:source>elib.cc</dc:source>
    </metadata>

    <manifest>
        <item href="toc.ncx" id="ncx" media-type="application/x-dtbncx+xml" />
        %s
    </manifest>
    <spine toc="ncx">
        %s
    </spine>
  
  <guide>
  </guide>
</package>
"""

EPUB_TOC_NCX_DATA = """<?xml version="1.0" encoding="utf-8" ?>
<!DOCTYPE ncx PUBLIC "-//NISO//DTD ncx 2005-1//EN"
"http://www.daisy.org/z3986/2005/ncx-2005-1.dtd">
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="urn:uuid:d981dee5-6fed-4c0a-8e36-1wsq112sswwe" />
    <meta name="dtb:depth" content="3" />
    <meta name="dtb:totalPageCount" content="0" />
    <meta name="dtb:maxPageNumber" content="0" />
  </head>
  <docTitle>
    <text>个人收藏</text>
  </docTitle>
  <navMap>
        %s
  </navMap>
</ncx>
"""

EPUB_TOC_NCX_NAVPOINT_DATA = """
    <navPoint id="navPoint-${index}" playOrder="${index}">
      <navLabel>
        <text>${name}</text>
      </navLabel>
      <content src="${src}" />
    </navPoint>
"""


def _getMediaType(file):
    mediaType = ""
    if file.endswith(".css"):
        mediaType = "text/css"
    if file.endswith(".js"):
        mediaType = "text/js"
    if file.endswith(".jpeg"):
        mediaType = "image/jpeg"
    if file.endswith(".jpg"):
        mediaType = "image/jpeg"
    if file.endswith(".png"):
        mediaType = "image/png"
    if file.endswith(".gif"):
        mediaType = "image/gif"
    return mediaType


def _zipFile(src_dir, name):
    z = zipfile.ZipFile(name, 'w', zipfile.ZIP_DEFLATED)
    for dirpath, dirnames, filenames in os.walk(src_dir):
        fpath = dirpath.replace(src_dir,"")
        fpath = fpath and fpath + os.sep or ""
        for filename in filenames:
            z.write(os.path.join(dirpath, filename),fpath+filename)
    z.close()


def _generateDir():
    if not os.path.exists(EPUB_OUTPUT_DIR):
        os.makedirs(EPUB_OUTPUT_DIR)

    if not os.path.exists(EPUB_META_PATH):
        os.makedirs(EPUB_META_PATH)
    if not os.path.exists(EPUB_CONTENT_PATH):
        os.makedirs(EPUB_CONTENT_PATH)

    if not os.path.exists(EPUB_ARTICLE_PATH):
        os.makedirs(EPUB_ARTICLE_PATH)

    with open(EPUB_META_CONTAINER_FILE, "w") as file:
        file.write(EPUB_META_CONTAINER_DATA)

    with open(EPUB_MINETYPE_FILE, "w") as file:
        file.write("application/epub+zip")

    mode = os.stat(EPUB_MINETYPE_FILE).st_mode
    mode |= (mode & 0o444) >> 2    # copy R bits to X
    os.chmod(EPUB_MINETYPE_FILE, mode)
    pass


def __generateNcx(navPointList):
    with open(EPUB_TOC_NCX_FILE, "w") as file:
        content = EPUB_TOC_NCX_DATA % (" ".join(navPointList))
        file.write(content)
    pass


def __generateOpf(items, itemRefs):
    items = __moveFile(items)
    with open(EPUB_CONTENT_FILE, "w") as file:
        content = EPUB_CONTENT_DATA % ("".join(items), "".join(itemRefs))
        file.write(content)
    pass


def __moveFile(items):
    # 复制与注册vender
    LogI("epub vender复制与生成item->开始")
    venderDir = ".." + Macros.VENDER_DIR
    shutil.copytree(venderDir, EPUB_VENDER_PATH)
    venderList = Util.getAllFileInDir(EPUB_VENDER_PATH)
    items = __parseItems(items, venderList)
    LogI("epub vender复制与生成item->结束")

    # 复制与注册image
    LogI("epub image复制与生成item->开始")
    imageDir = Macros.MARDDOWN_DIR + Macros.ARTICLE_IMAGES_DIR_NAME
    shutil.copytree(imageDir, EPUB_IMAGE_PATH)
    imageList = Util.getAllFileInDir(EPUB_IMAGE_PATH)
    items = __parseItems(items, imageList)
    LogI("epub image复制与生成item->结束")

    return items


def __parseItems(items, fileList):
    for file in fileList:
        if "DS_Store" in file:
            continue
        if file.endswith(".md"):
            continue

        file = Util.convert_character(file, 
                        os.path.join(EPUB_OUTPUT_DIR, EPUB_CONTENT_DIR), 
                        "")
        mediaType = _getMediaType(file)
        itemDict = {
            "href": file,
            "id": file,
            "mediaType": mediaType
        }
        tpl = TPL(EPUB_CONTENT_ITEM_DATA)
        item = tpl.substitute(itemDict)
        items.append(item)
    return items


def generatorEPUB():
    LogI("开始生成epub")
    begin = datetime.datetime.now()
    if os.path.exists(EPUB_OUTPUT_DIR):
        shutil.rmtree(EPUB_OUTPUT_DIR)
    _generateDir()

    navPointList = []
    items = []
    itemRefs = []

    index = 1
    for name, contentDict in Global.globalArticleDict.items():
        fullName = name+"."+Macros.POSTFIX
        filePath = os.path.join(EPUB_ARTICLE_PATH, fullName)
        title = contentDict["title"]
        content = contentDict["content"]
        content = Util.convert_character(content, "./image", "../image")
        content = Util.convert_character(content, '.webp"', '.png"')
        content = Util.convert_character(content, '&nbsp;', '')
        content = Util.convert_character(content, '&copy;', '')
        content = Util.convert_character(content, 'alt="">', 'alt="" />')
        Util.writeContentToFile(filePath, content)
        LogI("epub文章生成: "+title)

        src = os.path.join(EPUB_ARTICLE_DIR, fullName)
        
        navPointDict = {
            "index": str(index),
            "name": title,
            "src": src
        }
        tpl = TPL(EPUB_TOC_NCX_NAVPOINT_DATA)
        navPoint = tpl.substitute(navPointDict)
        navPointList.append(navPoint)

        itemDict = {
            "href": src,
            "id": fullName,
            "mediaType": "application/html+xml"
        }
        tpl = TPL(EPUB_CONTENT_ITEM_DATA)
        item = tpl.substitute(itemDict)
        items.append(item)

        itemRef = EPUB_CONTENT_ITEM_REF_DATA % fullName
        itemRefs.append(itemRef)
        
        index = index+1
        pass
    __generateNcx(navPointList)
    __generateOpf(items, itemRefs)

    _zipFile(EPUB_OUTPUT_DIR, EPUB_FINAL_NAME)
    if os.path.exists(EPUB_OUTPUT_DIR):
        shutil.rmtree(EPUB_OUTPUT_DIR)

    end = datetime.datetime.now()
    LogI(('epub生成所需时间: %.3f 秒' % (end - begin).seconds))
    pass


if __name__ == '__main__':
    
    pass














