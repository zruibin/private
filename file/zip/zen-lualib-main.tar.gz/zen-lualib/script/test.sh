cd ..

cd src-rs
if [[ $OSTYPE == 'darwin'* ]]; then
    cargo rustc -- -C link-arg=-undefined -C link-arg=dynamic_lookup
    cp ../src-rs/target/debug/libext.dylib ../src-rs/target/debug/libext.so
else
    cargo build
fi

cd ..
rm -rf test_temp
mkdir  test_temp
cp -r  src/*                     test_temp
cp -r  unittest/*                test_temp
cp src-rs/target/debug/libext.so test_temp
cd test_temp
./lua5.4 test_framework.lua
