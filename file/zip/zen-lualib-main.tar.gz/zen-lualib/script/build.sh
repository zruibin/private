cd ..

cd src-rs
if [[ $OSTYPE == 'darwin'* ]]; then
    cargo rustc --release -- -C link-arg=-undefined -C link-arg=dynamic_lookup
    cp ../src-rs/target/release/libext.dylib ../src-rs/target/release/libext.so
else
    cargo build --release
fi

cd ..
rm -rf build
mkdir  build
cp -r  src/*                           build
cp     src-rs/target/release/libext.so build
