rm -rf ../test_temp
rm -rf ../build
rm -rf ../src-rs/target
