local ext_test = {
    httpc = function()
        local ext = require("libext")
        local req = ext.new_http_request({
            scheme = "https",
            host = "www.baidu.com",
            port = "443",
            method = "GET",
            url = "",
            headers = {},
            timeout = 500,
            version = "HTTP1.1"
        }):request()
        assert(req:status() == "200 OK")
    end
}

return ext_test
