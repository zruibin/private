local collection_test = {
    stack = function()
        local Stack = require("collections.stack")

        local stack = Stack:new()
        stack:push(1)
        stack:push(2)
        stack:push(3)

        assert(stack:pop() == 3)
        assert(stack:pop() == 2)
        assert(stack:pop() == 1)
        assert(stack:pop() == nil)
    end,
    deque = function()
        local Deque = require("collections.deque")

        local deque = Deque:new()
        deque:push(1)
        deque:push_front(0)
        deque:push(2)
        deque:push_front(-1)
        deque:push(3)

        assert(deque:pop_front() == -1)
        assert(deque:pop() == 3)
        assert(deque:pop_front() == 0)
        assert(deque:pop() == 2)
        assert(deque:pop() == 1)
        assert(deque:pop() == nil)
    end
}

return collection_test
