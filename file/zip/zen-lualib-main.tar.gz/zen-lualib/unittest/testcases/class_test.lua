local class_test = {
    trivial = function()
        local class = require("class")
        local BaseObject = class.CreateClass {
            data = { z = 3 }
        }
        local DerivedObject = class.CreateClass {
            inherit = BaseObject,
            data = { data = 0, x = 1, y = 2 },
            methods = {
                constructor = function(self, x, y)
                    self.x = x
                    self.y = y
                end
            },
        }

        local newobj = DerivedObject:new(1, 2)

        assert(class.IsClass(BaseObject))
        assert(newobj:instanceof(BaseObject))
        assert(newobj:instanceof(DerivedObject))
    end,
    override = function()
        local class = require("class")
        local BaseObject = class.CreateClass {
            methods = {
                override = class.PureVirtual
            }
        }
        local DerivedObject = class.CreateClass {
            inherit = BaseObject,
            methods = {
                override = function(_)
                    return true
                end
            },
        }
        assert(DerivedObject:new():override())
    end,
    inherits = function()
        local class = require("class")

        local BaseBase = class.CreateClass {
            methods = {
                provide = class.PureVirtual,
                setdata = class.PureVirtual,
            }
        }

        local BaseObjectX = class.CreateClass {
            inherit = BaseBase,
            methods = {
                add = class.PureVirtual,
                mul = class.PureVirtual,
            }
        }
        local DerivedObjectX = class.CreateClass {
            inherit = BaseObjectX,
            methods = {
                add = function(self, input)
                    return self:setdata(self:provide() + input)
                end,
                mul = function(self, input)
                    return self:setdata(self:provide() * input)
                end
            }
        }
        local BaseObjectY = class.CreateClass {
            inherit = BaseBase,
            methods = {
                div = class.PureVirtual,
                sub = class.PureVirtual,
            }
        }
        local DerivedObjectY = class.CreateClass {
            inherit = BaseObjectY,
            methods = {
                div = function(self, input)
                    return self:setdata(self:provide() / input)
                end,
                sub = function(self, input)
                    return self:setdata(self:provide() - input)
                end
            }
        }
        local DerivedObjectFinal = class.CreateClass {
            inherits = { BaseBase, DerivedObjectX, DerivedObjectY },
            data = { inner = 0 },
            methods = {
                constructor = function(self, inner)
                    if inner ~= nil then
                        self.inner = inner
                    end
                end,
                provide = function(self)
                    return self.inner
                end,
                setdata = function(self, value)
                    self.inner = value
                    return value
                end
            }
        }

        local object = DerivedObjectFinal:new(1)
        assert(object:add(1) == 2)
        assert(object:mul(4) == 8)
        assert(object:div(4) == 2)
        assert(object:sub(2) == 0)
    end
}

return class_test
