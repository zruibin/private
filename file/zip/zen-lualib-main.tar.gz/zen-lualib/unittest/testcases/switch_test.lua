local switch_test = {
    common = function()
        local switch = require("switch")

        local ok = switch
            :new()
            :case {
                pattern = "Hello",
                handler = function()
                    return true
                end
            }
            :match("Hello")
        assert(ok)
    end,
    default = function()
        local switch = require("switch")

        local ok = switch
            :new()
            :default {
                function()
                    return true
                end
            }
            :match("Hello")
        assert(ok)
    end
}

return switch_test
