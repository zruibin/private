local function test(name, testcase)
  local ret, error = pcall(testcase)
  if ret == true then
    print("testcase[" .. name .. "] ok")
  else
    print("testcase[" .. name .. "] fail")
    print(error)
  end
end

--- 卸载读取的库，以备再次读取
---@param name string 库的名字
local function remove_required_libs(name)
  for key, _ in pairs(package.preload) do
    if string.find(tostring(key), name) == 1 then
      package.preload[key] = nil
    end
  end
  for key, _ in pairs(package.loaded) do
    if string.find(tostring(key), name) == 1 then
      package.loaded[key] = nil
    end
  end
end

local testcases = require("testcases")

local function main()
  print("-------------------")
  print("test start")
  for i = 1, #testcases do
    print("-------------------")
    test(i, testcases[i])
  end
  print("-------------------")
  print("test end")
  print("-------------------")
end
main()
