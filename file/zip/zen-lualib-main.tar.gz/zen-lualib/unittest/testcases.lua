local class_test = require("testcases.class_test")
local switch_test = require("testcases.switch_test")
local collection_test = require("testcases.collection_test")
local ext_test = require("testcases.ext_test")

return {
    [1] = class_test.trivial,
    [2] = class_test.override,
    [3] = class_test.inherits,
    [4] = switch_test.common,
    [5] = switch_test.default,
    [6] = collection_test.stack,
    [7] = collection_test.deque,
    [8] = ext_test.httpc,
}
