local class = require("class")

local iterator = class.CreateClass {
  methods = {
    next = class.PureVirtual,

    forEach = function(self, f)
      local item = self:next()
      while item ~= nil do
        f(item)
        item = self:next()
      end
    end,
    all = function (self, f)
      local item = self:next()
      while item ~= nil do
        local result = f(item)
        if type(result) == "boolean" and result == false then
          return false
        end
        item = self:next()
      end
      return true
    end,
    any = function (self, f)
      local item = self:next()
      while item ~= nil do
        local result = f(item)
        if type(result) == "boolean" and result == true then
          return true
        end
        item = self:next()
      end
      return false
    end
  }
}

return iterator
