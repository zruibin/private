local class = require("class")

local dummyVal = {}

local set = class.CreateClass {
  data = { inner = {} },
  metafields = {
    __pairs = function(self)
      return pairs(self.inner)
    end,
  },
  methods = {
    add = function(self, item)
      self.inner[item] = dummyVal
    end,
    remove = function(self, item)
      self.inner[item] = nil
    end,
    unionWith = function(self, another)
      for key, _ in pairs(another) do
        self[key] = dummyVal
      end
    end,
    issubset = function(self, another)
      for key, _ in pairs(another) do
        if self[key] == nil then
          return false
        end
      end
      return true
    end
  }
}

return set
