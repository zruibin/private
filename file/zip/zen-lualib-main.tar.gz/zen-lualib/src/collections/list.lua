local class = require("class")
local AbstractList = require("collections.abstractlist")

local list = class.CreateClass {
  inherit = AbstractList,
  data = { inner = {} },
  metafields = {
    __index = function(self, index)
      if type(index) == "number" then
        return self.inner[index]
      else
        return nil
      end
    end,
    __pairs = function(self)
      return pairs(self.inner)
    end
  },
  methods = {
    constructor = function(self, ...)
      if #{ ... } == 0 then
        return
      end
      self.inner = { ... }
    end,
    isReadonly = function(_)
      return false
    end,
    fixedsized = function(_)
      return false
    end,
    add = function(self, item)
      table.insert(self.inner, item)
    end,
    contains = function(self, item)
      for _, value in pairs(self.inner) do
        if value == item then
          return true
        end
      end
      return false
    end,
    indexof = function(self, item)
      for key, value in pairs(self.inner) do
        if value == item then
          return key
        end
      end
      return nil
    end,
    insert = function(self, index, item)
      table.insert(self.inner, index, item)
    end,
    remove = function(self, item)
      local index = self:indexof(item)
      if index == nil then
        return
      end
      local size = #self.inner
      self.inner[index] = nil
      for i = index + 1, size, 1 do
        self.inner[i - 1] = self.inner[i]
      end
    end,
    removeAt = function(self, index)
      if index == nil then
        return
      end
      local size = #self.inner
      self.inner[index] = nil
      for i = index + 1, size, 1 do
        self.inner[i - 1] = self.inner[i]
      end
    end,
    len = function(self)
      return #self.inner
    end
  },
}

return list
