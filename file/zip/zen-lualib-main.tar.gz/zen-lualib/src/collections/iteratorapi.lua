local class = require("class")

local iteratorapi = class.CreateClass {
  methods = {
    iter = class.PureVirtual
  }
}

return iteratorapi
