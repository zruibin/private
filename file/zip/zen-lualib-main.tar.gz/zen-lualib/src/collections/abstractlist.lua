local class = require("class")

local ilist = class.CreateClass {
  methods = {
    isReadonly = class.PureVirtual,
    fixedsized = class.PureVirtual,
    add = class.PureVirtual,
    clear = class.PureVirtual,
    contains = class.PureVirtual,
    indexof = class.PureVirtual,
    insert = class.PureVirtual,
    remove = class.PureVirtual,
    removeAt = class.PureVirtual,
    len = class.PureVirtual,
  }
}

return ilist
