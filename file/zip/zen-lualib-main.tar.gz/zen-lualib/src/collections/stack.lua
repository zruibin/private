local class = require("class")

local List = require("collections.list")

local stack = class.CreateClass {
  data = { inner = List:new() },
  methods = {
    constructor = function(self, ...)
      self.inner = List:new(...)
    end,
    push = function(self, item)
      self.inner:add(item)
    end,
    pop = function(self)
      local len = self.inner:len()
      local ret = self.inner[len]
      self.inner:removeAt(len)
      return ret
    end
  }
}

return stack
