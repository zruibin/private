local class = require("class")

local stack = class.CreateClass {
  data = { inner = {}, rangeL = 1, rangeR = 0 },
  methods = {
    constructor = function(self, ...)
      self.inner = { ... }
      self.rangeR = #self.inner
    end,
    len = function(self)
      local ret = self.rangeR - self.rangeL + 1
      return ret > 0 and ret or 0
    end,
    push = function(self, item)
      self.rangeR = self.rangeR + 1
      self.inner[self.rangeR] = item
    end,
    pop = function(self)
      if self.rangeR < self.rangeL then
        return nil
      end
      local ret = self.inner[self.rangeR]
      self.inner[self.rangeR] = nil
      self.rangeR = self.rangeR - 1
      return ret
    end,
    push_front = function(self, item)
      self.inner[self.rangeL - 1] = item
      self.rangeL = self.rangeL - 1
    end,
    pop_front = function(self)
      if self.rangeR < self.rangeL then
        return nil
      end
      local ret = self.inner[self.rangeL]
      self.inner[self.rangeL] = nil
      self.rangeL = self.rangeL + 1
      return ret
    end
  }
}

return stack
