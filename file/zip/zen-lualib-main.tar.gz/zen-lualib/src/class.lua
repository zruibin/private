--- Search a value by key from a list of table
---
---@param key any
---@param tables table
---@return any
local function searchmethod(key, tables)
    for _, super in pairs(tables) do
        if super.methods ~= nil and super.methods[key] then
            return super.methods[key]
        end
    end

    for _, super in pairs(tables) do
        local ret = searchmethod(key, super:superclasses())
        if ret ~= nil then
            return ret
        end
    end
    return nil
end

--- Merge two tables, if two tables has same index, then use the latter table's
---
---@param ... table
---@return table
local function merge(...)
    local result = {}
    for _, eachtable in pairs { ... } do
        for k, v in pairs(eachtable) do result[k] = v end
    end
    return result
end

--- Deepcopy a object
---
---@param originalObject table
---@return table
local function deepcopy(originalObject)
    if type(originalObject) == 'table' then
        local copy = {}
        for key, value in next, originalObject, nil do
            copy[deepcopy(key)] = deepcopy(value)
        end
        setmetatable(copy, deepcopy(getmetatable(originalObject)))
        return copy
    else -- number, string, boolean, etc
        return originalObject
    end
end

--- # GetSuperClassList
--- Provide a classObject, return a list of super class
---
--- ## Example
--- ```Lua
--- local BaseObject = class()
---
--- local DerivedObject = class({
---     inherit = BaseObject,
---     constructor = function(self, x, y)
---         self.x = x
---         self.y = y
---     end
--- })
--- local superclasses = GetSuperClassList(DerivedObject) -- { BaseObject }
--- ```
---@param classObject table
---@return table
local function GetSuperClassList(classObject)
    return classObject.inherits or { classObject.inherit }
end

--- # CheckIsSubclass
---
--- ## Example
--- ```Lua
--- local BaseObject = CreateClass()
--- local DerivedObject = CreateClass({ inherit = BaseObject })
---
--- assert(IsSubclass(DerivedObject, BaseObject)) -- no error throw
--- ```
---@param classToCheck table
---@param classObject table
---@return boolean issubclass
local function IsSubclass(classToCheck, classObject)
    if classToCheck == classObject then
        return true
    end
    for _, superclass in pairs(classToCheck:superclasses()) do
        if superclass == classObject or superclass:issubclass(classObject) then
            return true
        end
    end
    return false
end

local classSet = {}
local dummyVal = {}

--- # CreateClass
--- Create a class object
---
--- ## Example
--- ```Lua
--- local BaseObject = CreateClass({
---     data = { z = 3 }
--- })
---
--- local DerivedObject = CreateClass({
---     inherit = BaseObject,
---     data = { data = 0, x = 1, y = 2 },
---     methods = {
---         constructor = function(self, x, y)
---             self.x = x
---             self.y = y
---         end
---     },
--- })
---
--- local json = require("json")
--- print(json:encode(DerivedObject:new(1, 2))) -- {"data":0,"x":1,"y":2,"z":3}
--- ```
---
--- ## Parameter structure
--- ```
--- structure ClassDef {
---     -- father class, inherit is single inheritance,
---     -- you can only use one of inherit and inherits
---     inherit: ClassObject | nil,
---     -- father classes, inherits is multi inheritance,
---     -- you can only use one of inherit and inherits
---     inherits: List<ClassObject> | nil,
---     -- self defined data field, each object of this class will copy this table
---     data: Object | nil,
---     -- self defined methods, represents metatable field __index
---     methods: Table<String, Function> | nil,
---     -- self defined metatable fields, for example: __eq, __pairs
---     metafields: Table<String, Function> | nil
--- }
--- ```
---@param classDef table | nil
---@return table classObject
local function CreateClass(classDef)
    -- you can skip classDef and we would use a default value
    local classDef = classDef or {}
    -- multi inherit use inherits and single inherit use inherit
    local supers = classDef.inherits or { classDef.inherit }
    -- provide self defined metafields
    local metafields = classDef.metafields
    -- inheritance of metafields
    local function inheritMetafields(classObject)
        local superclassList = GetSuperClassList(classObject)
        for _, superclass in pairs(superclassList) do
            metafields = merge(deepcopy(superclass.metafields), metafields)
        end
    end
    inheritMetafields(classDef)
    -- provide self defined methods
    local methods = merge(classDef.methods, {
        getclass = function(_)
            return classDef
        end,
        getsuperclasses = function(self)
            return self:getclass():superclasses()
        end,
        instanceof = function(self, classObject)
            return self:getclass():issubclass(classObject)
        end
    })
    -- inheritance of methods, using searchmethod
    local indexer = function(self, key)
        -- search methods table first
        local ret = methods[key]
        if ret ~= nil then
            return ret
        end
        -- prevent from searching super's constructor
        if key == "constructor" then
            return nil
        end

        -- search supers and self defined __index latter
        local ret = nil
        -- if self defined __index is not nil, use it
        if type(metafields.__index) == "table" then
            ret = metafields.__index[key]
        elseif type(metafields.__index) == "function" then
            ret = metafields.__index(self, key)
        end
        -- cannot found in self defined __index, fall through to searchmethod
        if ret == nil then
            ret = searchmethod(key, supers)
        end
        return ret
    end
    -- provide self defined class metatable
    local metatable = merge(metafields, { __index = indexer })
    -- inheritance of data
    local function inheritData(classObject)
        local superclassList = GetSuperClassList(classObject)
        for _, superclass in pairs(superclassList) do
            classDef.data = merge(deepcopy(superclass.data), classDef.data)
        end
    end
    inheritData(classDef)

    -- register operator superclasses
    classDef.superclasses = function(_)
        return GetSuperClassList(classDef)
    end
    -- register operator issubclass
    classDef.issubclass = function(_, classObject)
        return IsSubclass(classDef, classObject)
    end
    -- register operator constructor
    classDef.getconstructor = function(_)
        return classDef.methods.constructor
    end
    -- register operator new
    classDef.new = function(_, ...)
        local instance = deepcopy(classDef.data)
        -- self defined metatable
        setmetatable(instance, metatable)
        -- self defined constructor
        if instance.constructor ~= nil then
            instance:constructor(...)
        end
        return instance
    end

    -- register classObject to classSet
    classSet[classDef] = dummyVal

    return classDef
end

--- # IsClass
--- Check a object is class object or not
---
--- ## Example
--- ```Lua
--- local BaseObject = class.CreateClass({
---     data = { z = 3 }
--- })
--- assert(class.IsClass(BaseObject)) -- no error throw
--- ```
---@param classObject table
---@return boolean
local function IsClass(classObject)
    return classSet[classObject] ~= nil
end

--- # PureVirtual
--- - PureVirtual function,
--- - Using this function, we can simulate pure virtual function in c plus plus
local function PureVirtual()
    error("Hit pure virtual function! Your class should override this fucntion.")
end

return {
    IsClass = IsClass,
    CreateClass = CreateClass,
    PureVirtual = PureVirtual,
}
