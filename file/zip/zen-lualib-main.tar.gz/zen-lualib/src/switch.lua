local class = require("class")

local alwaysTrue = function()
    return true
end

local switch = class.CreateClass {
    data = {
        patterns = {}
    },
    methods = {
        --- # Case
        --- Provide a handler of switch
        ---
        --- ## Example
        --- ```Lua
        --- local ok = switch
        ---     :new()
        ---     :case({
        ---         pattern = "Hello",
        ---         handler = function()
        ---             return true
        ---         end
        ---     })
        ---     :match("Hello")
        --- assert(ok) -- no error throw
        --- ```
        --- ## Parameter structure
        --- ```
        --- structure Case {
        ---     pattern: Any,
        ---     handler: Function Any -> Boolean,
        --- }
        --- ```
        --- ### Pattern
        --- pattern can be function, table, or other type
        --- - function: if pattern is function, when matching a value, will call this function by pattern(value)
        --- - table: if pattern is table, when matching a value, will search whether the value is in table or not
        --- - other: if pattern is other types, when matching a value, will check whether pattern equals value or not
        ---
        --- after checking a pattern, we got a boolean result, if true, do handler, if not, check next pattern
        ---@param self table
        ---@param case table
        ---@return table
        case = function(self, case)
            table.insert(self.patterns, case)
            return self
        end,
        --- # Default
        --- Provide a default handler of switch
        ---
        --- ## Example
        --- ```Lua
        --- local ok = switch
        ---     :new()
        ---     :default({
        ---         function()
        ---             return true
        ---         end
        ---     })
        ---     :match("Hello")
        --- ```
        --- ## Parameters
        --- ```
        --- -- A List of Function, when it comes to default branch, all of the functions would be called
        --- handlers: List<Function nil -> Any>
        --- ```
        ---@param self any
        ---@param handlers table
        ---@return table
        default = function(self, handlers)
            local _, handler = next(handlers, nil)
            if #handlers > 1 then
                handler = function()
                    for _, handler in pairs(handlers) do
                        handler()
                    end
                end
            end
            table.insert(self.patterns, {
                pattern = alwaysTrue,
                handler = handler
            })
            return self
        end,
        --- # Match
        --- Match patterns and then run the callback
        ---
        --- ## Example
        --- ```Lua
        --- local ok = switch
        ---     :new()
        ---     :case({
        ---         pattern = "Hello",
        ---         handler = function()
        ---             return true
        ---         end
        ---     })
        ---     :match("Hello")
        --- assert(ok) -- no error throw
        --- ```
        ---@param self table
        ---@param matcher any
        match = function(self, matcher)
            for _, case in pairs(self.patterns) do
                if type(case.pattern) == "table" then
                    for _, pattern in pairs(case.pattern) do
                        if pattern == matcher then
                            return case.handler()
                        end
                    end
                elseif type(case.pattern) == "function" then
                    if case.pattern(matcher) then
                        return case.handler()
                    end
                elseif matcher == case.pattern then
                    return case.handler()
                end
            end
        end
    }
}

return switch
