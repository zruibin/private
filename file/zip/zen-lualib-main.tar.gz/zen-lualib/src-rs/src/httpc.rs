// Self Mods
use crate::util::transform::Transformation;
// Standard Mods
use std::{collections::HashMap, time::Duration};
// External Mods
use mlua::{FromLua, Lua, UserData, UserDataFields};
use reqwest::{
    header::{HeaderName, HeaderValue},
    Version,
};
use serde::{Deserialize, Serialize};
use typed_builder::TypedBuilder;

#[derive(Deserialize, Serialize, Debug, Clone, TypedBuilder)]
pub struct HttpRequest {
    pub scheme: String,
    pub host: String,
    pub port: u32,
    pub method: String,
    pub url: String,
    pub headers: HashMap<String, String>,
    pub timeout: u32,
    pub version: String,
    // Fields that could be none
    #[builder(default, setter(strip_option))]
    pub body: Option<Vec<u8>>,
}

impl UserData for HttpRequest {
    fn add_fields<'lua, F: UserDataFields<'lua, Self>>(fields: &mut F) {
        fields.add_field_method_get("scheme", |_, this| Ok(this.scheme.clone()));
        fields.add_field_method_get("host", |_, this| Ok(this.host.clone()));
        fields.add_field_method_get("port", |_, this| Ok(this.port.clone()));
        fields.add_field_method_get("method", |_, this| Ok(this.method.clone()));
        fields.add_field_method_get("url", |_, this| Ok(this.url.clone()));
        fields.add_field_method_get("headers", |_, this| Ok(this.headers.clone()));
        fields.add_field_method_get("timeout", |_, this| Ok(this.timeout.clone()));
        fields.add_field_method_get("version", |_, this| Ok(this.version.clone()));
        fields.add_field_method_get("body", |_, this| Ok(this.body.clone()));

        fn setter<T: for<'a> FromLua<'a>>(
            setterfn: impl Fn(&mut HttpRequest) -> &mut T,
        ) -> impl FnMut(&Lua, &mut HttpRequest, T) -> mlua::Result<()> {
            move |_, this, data| {
                *setterfn(this) = data;
                Ok(())
            }
        }
        fields.add_field_method_set("scheme", setter(|this| &mut this.scheme));
        fields.add_field_method_set("host", setter(|this| &mut this.host));
        fields.add_field_method_set("port", setter(|this| &mut this.port));
        fields.add_field_method_set("method", setter(|this| &mut this.method));
        fields.add_field_method_set("url", setter(|this| &mut this.url));
        fields.add_field_method_set("headers", setter(|this| &mut this.headers));
        fields.add_field_method_set("timeout", setter(|this| &mut this.timeout));
        fields.add_field_method_set("version", setter(|this| &mut this.version));
        fields.add_field_method_set("body", setter(|this| &mut this.body));
    }
    fn add_methods<'lua, M: mlua::UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_function("request", |_, request: HttpRequest| {
            let method = reqwest::Method::from_bytes(request.method.as_bytes())
                .map_err(|_| mlua::Error::SerializeError("Method invalid".to_string()))?;
            let url = format!(
                "{}://{}:{}/{}",
                request.scheme, request.host, request.port, request.url
            );
            let headers = {
                request
                    .headers
                    .iter()
                    .map(|(k, v)| {
                        (
                            HeaderName::try_from(k).unwrap(),
                            HeaderValue::try_from(v).unwrap(),
                        )
                    })
                    .collect()
            };
            let timeout = Duration::from_millis(request.timeout.into());
            let version = match request.version.as_str() {
                "HTTP1.0" => Version::HTTP_10,
                "HTTP1.1" => Version::HTTP_11,
                "HTTP2" => Version::HTTP_2,
                "HTTP3" => Version::HTTP_3,
                // If nothing, use http1.1
                _ => Version::HTTP_11,
            };
            reqwest::blocking::Client::new()
                .request(method, url)
                // Prepare body
                .transformation(|req| {
                    if let Some(body) = request.body {
                        req.body(reqwest::blocking::Body::try_from(body).unwrap())
                    } else {
                        req
                    }
                })
                // Prepare other parameters
                .headers(headers)
                .timeout(timeout)
                .version(version)
                .send()
                .map(|ok| HttpResponse(ok))
                .map_err(|err| {
                    mlua::Error::RuntimeError(format!("Http request error, {}", err.to_string()))
                })
        });
    }
}

pub struct HttpResponse(pub reqwest::blocking::Response);

impl<'lua> FromLua<'lua> for HttpResponse {
    fn from_lua(lua_value: mlua::Value<'lua>, _: &'lua Lua) -> mlua::Result<Self> {
        match lua_value {
            mlua::Value::UserData(resp) => resp.take::<HttpResponse>(),
            _ => Err(mlua::Error::RuntimeError("Type mismatch".to_string())),
        }
    }
}
impl UserData for HttpResponse {
    fn add_methods<'lua, M: mlua::UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_method("status", |_, response, _: ()| {
            Ok(response.0.status().to_string())
        });
        methods.add_method("version", |_, response, _: ()| {
            Ok(match response.0.version() {
                Version::HTTP_10 => "HTTP1.0",
                Version::HTTP_11 => "HTTP1.1",
                Version::HTTP_2 => "HTTP2",
                Version::HTTP_3 => "HTTP3",
                _ => unreachable!(),
            })
        });
        methods.add_method("headers", |lua, response, _: ()| {
            Ok(lua.create_table_from(
                response
                    .0
                    .headers()
                    .iter()
                    .map(|(key, val)| (key.to_string(), val.as_bytes())),
            ))
        });
        methods.add_method("cookies", |lua, response, _: ()| {
            Ok(lua.create_table_from(
                response
                    .0
                    .cookies()
                    .enumerate()
                    .map(|(index, cookie)| (index, format!("{:?}", cookie))),
            ))
        });
        methods.add_method("url", |_, response, _: ()| Ok(response.0.url().to_string()));
        methods.add_method(
            "remote_addr",
            |_, response, _: ()| -> Result<String, mlua::Error> {
                Ok(match response.0.remote_addr() {
                    Some(addr) => format!("{}", addr),
                    None => "".to_string(),
                })
            },
        );
    }
}
