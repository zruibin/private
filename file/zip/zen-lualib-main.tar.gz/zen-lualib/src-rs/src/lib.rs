// Self Mods
mod httpc;
mod util;
// Self Mods
use httpc::{HttpRequest, HttpResponse};

// External Mods
use mlua::prelude::*;
use mlua::{self, Lua};

#[mlua::lua_module]
fn libext(lua: &Lua) -> LuaResult<LuaTable> {
    let exports = lua.create_table()?;
    exports.set(
        "new_http_request",
        lua.create_function(|_, table: mlua::Table| {
            let mut httprequest = HttpRequest::builder()
                .scheme(table.get("scheme")?)
                .host(table.get("host")?)
                .port(table.get("port")?)
                .method(table.get("method")?)
                .url(table.get("url")?)
                .headers(table.get("headers")?)
                .timeout(table.get("timeout")?)
                .version(table.get("version")?)
                .build();
            if let Ok(body) = table.get("body") {
                httprequest.body = Some(body);
            }
            Ok(httprequest)
        })?,
    )?;
    exports.set(
        "get_bytes",
        lua.create_function(|_, response: HttpResponse| {
            response
                .0
                .bytes()
                .map(|ok| ok.to_vec())
                .map_err(|err| mlua::Error::RuntimeError(err.to_string()))
        })?,
    )?;
    Ok(exports)
}
