g++ split_string_by_char.cc -mavx2 -o split_string_by_char

g++ split_string_by_string.cc -mavx2 -o split_string_by_string

g++ split_string_by_absl.cc -labsl_strings -labsl_strings_internal  -labsl_raw_logging_internal -labsl_string_view -o split_string_by_absl
